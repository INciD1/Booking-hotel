/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package booking_hotel.Images;

/**
 *
 * @author cchan
 */
public class test {
    public static void main(String[] args) {
        System.out.println("Hello");
    }
}
